import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/v1/auth': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
      '/v1/users': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
      '/v1/search': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
    },
  },

});


// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'

// export default defineConfig({
//   plugins: [react],
//   server: {
//     host: true,
//     allowedHosts: true,
//   },
// })
