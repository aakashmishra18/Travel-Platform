import React, { useState } from 'react';
import { User, Users, MapPin, Phone, Sliders, Award, FileCheck } from 'lucide-react';
import { ProfileInfoSection } from './ProfileInfoSection';
import { TravellersSection } from './TravellersSection';
import { AddressesSection } from './AddressesSection';
import { ContactsSection } from './ContactsSection';
import { PreferencesSection } from './PreferencesSection';
import { LoyaltySection } from './LoyaltySection';
import { ConsentsSection } from './ConsentsSection';

const TABS = [
  { key: 'info', label: 'Profile', icon: User, Component: ProfileInfoSection },
  { key: 'travellers', label: 'Travellers', icon: Users, Component: TravellersSection },
  { key: 'addresses', label: 'Addresses', icon: MapPin, Component: AddressesSection },
  { key: 'contacts', label: 'Contacts', icon: Phone, Component: ContactsSection },
  { key: 'preferences', label: 'Preferences', icon: Sliders, Component: PreferencesSection },
  { key: 'loyalty', label: 'Loyalty', icon: Award, Component: LoyaltySection },
  { key: 'consents', label: 'Consents', icon: FileCheck, Component: ConsentsSection },
];

export const ProfileHub = () => {
  const [activeTab, setActiveTab] = useState('info');
  const ActiveComponent = TABS.find((t) => t.key === activeTab)?.Component;

  return (
    <div>
      <div
        style={{
          display: 'flex',
          gap: 6,
          flexWrap: 'wrap',
          marginBottom: 20,
          borderBottom: '1px solid rgba(255,255,255,0.1)',
          paddingBottom: 12,
        }}
      >
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 12px',
              borderRadius: 6,
              border: 'none',
              cursor: 'pointer',
              fontSize: '0.8rem',
              fontWeight: 600,
              background: activeTab === key ? 'rgba(0, 240, 255, 0.15)' : 'transparent',
              color: activeTab === key ? '#00f0ff' : '#a0aec0',
            }}
          >
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      {ActiveComponent && <ActiveComponent />}
    </div>
  );
};
